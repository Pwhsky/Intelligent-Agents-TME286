﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;

namespace ChatbotLibrary
{
    [DataContract]
    public class Vocabulary
    {
        private List<WordData> wordDataList;


        public Vocabulary()
        {
            wordDataList =  new List<WordData>();
        }


        // Write this class - it should hold the vocabulary, i.e. the list of all distinct words (tokens) sorted
        // in alphabetical order, along with the IDFs, computed from the raw data set.

        // You may use a list of WordData instances if you wish (where each WordData instance would hold information
        // about one word).


        private void sortAlphabetical()
        {
            var n = wordDataList.Count;
            for (int i = 0; i < n - 1; i++)
                for (int j = 0; j < n - i - 1; j++)
                    if (string.Compare(wordDataList[j].Word, wordDataList[j + 1].Word) > 0)
                    {
                        WordData tempVar = wordDataList[j];
                        wordDataList[j] = wordDataList[j + 1];
                        wordDataList[j + 1] = tempVar;
                    }
        }
        public List<WordData> WordDataList
        {
            get { return wordDataList; }
            set { wordDataList = value; }
        }
       


    }
}
