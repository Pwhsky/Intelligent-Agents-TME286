﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace ChatbotLibrary
{
    public class Chatbot
    {
        protected const int DEFAULT_NUMBER_OF_MATCHES = 5;


        protected DialogueCorpus dialogueCorpus;
        protected Random randomNumberGenerator;
        protected int numberOfMatches = DEFAULT_NUMBER_OF_MATCHES;

        public virtual void Initialize()
        {
            randomNumberGenerator = new Random();
        }

        public void SetDialogueCorpus(DialogueCorpus dialogueCorpus)
        {
            this.dialogueCorpus = dialogueCorpus;

        }

        //
        // ToDo: Write the method below
        //
        // Given an input sentence, the method should 
        // compute the cosine similarity between the normalized
        // TF-IDF vector of the test sentence and the normalized
        // TF-IDF vectors of every sentence S_1 (i.e. the Query sentence
        // in each DialogueCorpusItem). The results should then be
        // sorted (you may add a class for this, perhaps with two fields,
        // one field for the index of the sentence pair (in the dialogue corpus), and
        // one field for the cosine similarity. Finally, a sentence pair should
        // be selected (as described below) and the corresponding Response should be returned.
        //
        // Then 
        // (i) sort the results in falling order of cosine similarity,
        // (ii) pick a random sentence pair (index) from among the top five (numberOfMatches, see above).
        // (iii) return sentence S_2 (Response) from the selected pair (DialogueCorpusItem).
        //
        //
        public virtual string GenerateResponse(string inputSentence)
        {
            if (string.IsNullOrWhiteSpace(inputSentence)) { return "Do not feed me empty words!"; }

            List<Tuple<int, double>> inputTFIDFTuple = ComputeTFIDFVector(dialogueCorpus.Vocabulary, inputSentence);
            double inputSentenceNorm                 = ComputeNorm(inputTFIDFTuple);

            List<Tuple<double, string>> outputTuple = new List<Tuple<double, string>>();

            for (int i = 0; i < dialogueCorpus.ItemList.Count; i++)
            {
                List<Tuple<int, double>> queryInDialogueCorpus = dialogueCorpus.ItemList[i].sparseTFIDFVector; //S_1 in corpus
                double querySentenceNorm = ComputeNorm(queryInDialogueCorpus);
                double hadamardProduct   = ComputeHadamardProduct(inputTFIDFTuple, queryInDialogueCorpus);
                double cosineSimilarity  = ComputCosineSimilarity(querySentenceNorm, inputSentenceNorm, hadamardProduct);

                if (double.IsNaN(cosineSimilarity)){continue;}

                Tuple<double, string> tupleToAdd = new Tuple<double, string>(cosineSimilarity, dialogueCorpus.ItemList[i].Response);
                outputTuple.Add(tupleToAdd);
            }
            return ChooseReply(outputTuple);
        }

        private string ChooseReply(List<Tuple<double, string>> TupleList)
        {

            if (!TupleList.Any()) { return "This is not in my vocabulary..."; }
            TupleList.Sort((x, y) => y.Item1.CompareTo(x.Item1));
            Random rnd = new Random();
            int randN  = rnd.Next(0, DEFAULT_NUMBER_OF_MATCHES - 1);
            return TupleList[randN].Item2;
        }

        public List<string> TokenizeInput(string inputLine)
        {
            inputLine = inputLine.ToLower();
            inputLine = inputLine.Replace("\n", "").Replace("\t", "").Replace("\u0085", "");
            inputLine = Regex.Replace(inputLine, @"[^\w\s'-]", "");
            inputLine = new string((from c in inputLine
                                    where char.IsWhiteSpace(c) || char.IsLetterOrDigit(c)
                                    select c).ToArray());

            List<string> tempList = inputLine.Split(' ').ToList();

            for (int i = 0; i < tempList.Count; i++)
            {
                if (string.IsNullOrWhiteSpace(tempList[i])) { tempList.RemoveAt(i); }
            }
            return tempList;
        }

        public List<Tuple<int, double>> ComputeTFIDFVector(Vocabulary dictionary, string inputSentence)
        {
            List<string> inputSentenceTokens = TokenizeInput(inputSentence);
            List<Tuple<int, double>> outputTuple = new List<Tuple<int, double>>();
            List<Tuple<int, double>> sparsetfIdfVector = new List<Tuple<int, double>>();

            //Initialize an empty vector of vocabulary length

            //List<Tuple<int, double>> sparseIdfVector = new List<Tuple<int, double>>() ;

            //Build the vector:
            foreach (string token in inputSentenceTokens)
            {
                if (string.IsNullOrEmpty(token) == true) { continue; }

                WordData termToSearch = new WordData();
                termToSearch.Word = token;

                int tokenIndexInVocabulary = dictionary.WordDataList.BinarySearch(termToSearch, new WordDataComparer());
                if (tokenIndexInVocabulary < 0) { continue; }

                double termFrequency = inputSentenceTokens.Count(s => s == token);

                Tuple<int, double> tupleToAdd = new Tuple<int, double>(tokenIndexInVocabulary,
                    dictionary.WordDataList[tokenIndexInVocabulary].IDF * termFrequency);

                sparsetfIdfVector.Add(tupleToAdd);

            }

            //Normalize the vector:
            double norm = 0;
            foreach (var entry in sparsetfIdfVector)
            {
                norm += entry.Item2 * entry.Item2;
            }
            norm = Math.Sqrt(norm);

            for (int i = 0; i < sparsetfIdfVector.Count; i++)
            {
                Tuple<int, double> tupleToAdd = new Tuple<int, double>
                    (sparsetfIdfVector[i].Item1, sparsetfIdfVector[i].Item2 / norm);
                outputTuple.Add(tupleToAdd);

            }

            return outputTuple;

        }

        private double ComputeNorm(List<Tuple<int, double>> inputTFIDFTuple)
        {
            double norm = 0;
            foreach (var entry in inputTFIDFTuple)
            {
                norm += entry.Item2 * entry.Item2;
            }
            norm = Math.Sqrt(norm);

            return norm;
        }
        private bool checkInput(string input)
        {
            List<string> inputTokens = TokenizeInput(input);

            foreach (string token in inputTokens)
            {
            WordData wordToCheck = new WordData();
            wordToCheck.Word = input;

               if( dialogueCorpus.Vocabulary.WordDataList
                    .BinarySearch(wordToCheck, new WordDataComparer()) < 0)
                {
                    return false;
                };

            }
            return true;
        }
        private double ComputeHadamardProduct(List<Tuple<int,double>> tuple1, List<Tuple<int,double>> tuple2)
        {
            
            var intersectingElements = from l1 in tuple1
                                       join l2 in tuple2
                                       on l1.Item1 equals l2.Item1
                                       select l1.Item2 * l2.Item2;

            if (!intersectingElements.Any()) { return 0; }
            else
            { return intersectingElements.Sum(); }

        }
        private double ComputCosineSimilarity(double norm1, double norm2, double hadamardProduct)
        {

            return hadamardProduct / (norm1 * norm2);
        }


    }
}
