﻿using NaturalLanguageProcessing.Dictionaries;
using NaturalLanguageProcessing.NGrams;
using NaturalLanguageProcessing.TextData;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace NGramsApplication
{
    public partial class MainForm : Form
    {
        private const string TEXT_FILTER = "Text files (*.txt)|*.txt";

        private TextDataSet writtenDataSet;
        private TextDataSet spokenDataSet;
        private NGramSet writtenUniGramSet;
        private NGramSet writtenBiGramSet;
        private NGramSet writtenTriGramSet;
        private NGramSet spokenUniGramSet;
        private NGramSet spokenBiGramSet;
        private NGramSet spokenTriGramSet;

        private Thread tokenizationThread;
        private Thread indexingThread;
        private Thread processingThread;

        private List<string> analysisList;

        public MainForm()
        {
            InitializeComponent();
        }

        private void ImportTextData(string fileName)
        {
            writtenDataSet = new TextDataSet();
            spokenDataSet = new TextDataSet();
            using (StreamReader dataReader = new StreamReader(fileName))
            {
                while (!dataReader.EndOfStream)
                {
                    string line = dataReader.ReadLine();
                    List<string> lineSplit = line.Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    Sentence sentence = new Sentence();
                    sentence.Text = lineSplit[1];
                    sentence.Text = sentence.Text.Replace(" , ", " ");

                    if (lineSplit[0] == "0") // Spoken sentence (Class 0)
                    {
                        spokenDataSet.SentenceList.Add(sentence);
                    }
                    else // Written sentence (Class 1)
                    {
                        writtenDataSet.SentenceList.Add(sentence);
                    }
                }
                dataReader.Close();
            }
        }

        private void importTextDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = TEXT_FILTER;
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    ImportTextData(openFileDialog.FileName);
                    tokenizeButton.Enabled = true;
                }
            }
        }

        // this methdo should display items in the analysis text box (it should be
        // called by ThreadSafeShowAnalysis().
        private void ShowAnalysis()
        {

            for (int i = 0; i < analysisList.Count; i++)
            {
                analysisTextBox.Text += analysisList[i] + "\r\n";
            }



        }
        // This method should, in turn, call ShowAnalysis() in a thread-safe manner
        private void ThreadSafeShowAnalysis()
        {
            if (InvokeRequired) { this.Invoke(new MethodInvoker(() => ShowAnalysis())); }
            else { ShowAnalysis(); }
        }

        private void ThreadSafeToggleButtonEnabled(ToolStripButton button, Boolean enabled)
        {
            if (InvokeRequired) { this.Invoke(new MethodInvoker(() => button.Enabled = enabled)); }
            else { button.Enabled = enabled; }
        }

        private void ThreadSafeToggleMenuItemEnabled(ToolStripMenuItem menuItem, Boolean enabled)
        {
            if (InvokeRequired) { this.Invoke(new MethodInvoker(() => menuItem.Enabled = enabled)); }
            else { menuItem.Enabled = enabled; }
        }

        private void TokenizationLoop()
        {
            writtenDataSet.Tokenize();
            spokenDataSet.Tokenize();
            ThreadSafeToggleButtonEnabled(makeDictionaryAndIndexButton, true);
        }

        private void tokenizeButton_Click(object sender, EventArgs e)
        {
            tokenizeButton.Enabled = false;
            tokenizationThread = new Thread(new ThreadStart(() => TokenizationLoop()));
            tokenizationThread.Start();
        }

        private void IndexingLoop()
        {
            writtenDataSet.MakeDictionaryAndIndex();
            spokenDataSet.MakeDictionaryAndIndex();
            ThreadSafeToggleButtonEnabled(processButton, true);
        }

        private void makeDictionaryAndIndexButton_Click(object sender, EventArgs e)
        {
            makeDictionaryAndIndexButton.Enabled = false;
            indexingThread = new Thread(new ThreadStart(() => IndexingLoop()));
            indexingThread.Start();
        }


        // ========================================================
        // Here, write methods for
        // ========================================================
        //
        // * Finding the 300 most common 1-grams, 2-grams, 3-grams in each set
        //     For the unigrams (1-grams), use the dictionary that you generated above.
        //     You must generate the sets of bigrams (2-grams) and trigrams (3-grams), using
        //     the NGramSet and its methods (see NGramSet.Append(...) ...)
        // * Finding the number of distinct tokens (unigrams) in the spoken set (i.e. the
        //   number of items in its dictionary) and the written set, as well as the number of shared (distinct) tokens.
        // * Finding the 50 tokens with the largest values of r (see the problem formulation)
        //     and the 50 tokens with the smallest values of r.
        // 
        private void ProcessingLoop()
        {
            const int COUNT_CUTOFF = 5;
            const int NUMBER_OF_N_GRAMS_SHOWN = 300;


            // Add your analysis as a list of strings (that can then be shown on screen and saved to file).
            analysisList = new List<string>();

            // Step (1)
            // Find the 300 most common unigrams (from the dictionaries, after sorting
            // the dictionary items based on the number of instances:
            Dictionary writtenUniGramDictionary = writtenDataSet.Dictionary;
            writtenUniGramSet = new NGramSet();
            writtenBiGramSet = new NGramSet();
            writtenTriGramSet = new NGramSet();

            Dictionary spokenUniGramDictionary = spokenDataSet.Dictionary;
            spokenUniGramSet = new NGramSet();
            spokenBiGramSet = new NGramSet();
            spokenTriGramSet = new NGramSet();


            //Find shared tokens using nested for-loop and compute the ratios
            //Add Ratio as a field to the DictionaryItem class for this.
            Dictionary sharedTokens = new Dictionary();

            //Pre-allocate doubles for performance

            int writtenCount;
            int spokenCount;
            double writtenSpokenRatio;
     

            //Sort so binary search can be used.
            //writtenUniGramDictionary.quickSort(0,writtenUniGramDictionary.ItemList.Count-1);
          
            //for (int j = 0; j < spokenUniGramDictionary.ItemList.Count; j++)
            foreach (DictionaryItem spokenItem in spokenUniGramDictionary.ItemList)
            {

                // writtenDictIndex = writtenUniGramDictionary.iterativeBinarySearch(spokenUniGramDictionary.ItemList[j]);
                int writtenDictIndex = writtenUniGramDictionary.ItemList.BinarySearch(spokenItem, new DictionaryItemComparer());

                if (writtenDictIndex < 0) {continue;}
                
                    writtenCount = writtenUniGramDictionary.ItemList[writtenDictIndex].Count;
                    spokenCount = spokenItem.Count;
                    writtenSpokenRatio = (double)writtenCount/(double)spokenCount;

                spokenItem.Ratio = writtenSpokenRatio;
                sharedTokens.ItemList.Add(spokenItem);
                
            }

            int distinctWrittenWords = writtenUniGramDictionary.ItemList.Count();
            int distinctSpokenWords = spokenUniGramDictionary.ItemList.Count();

            sharedTokens.ItemList.Sort((x, y) => x.Ratio.CompareTo(y.Ratio));

            //Sort and then access the ratios of the 50 and last 50 elements 

            // Add code here for generating and sorting the written bigram set.
            // Before sorting, run through the list and remove rare bigrams (speeds up
            // the sorting - we are only interested in the most frequent bigrams anyway;
            // see also the assignment text.




            //find unigrams
            writtenUniGramSet.ItemList = writtenUniGramDictionary.get300MostFrequent();
            spokenUniGramSet.ItemList = spokenUniGramDictionary.get300MostFrequent();

            analysisList.Add("=========================================");
            analysisList.Add("Written 1-grams: ");
            analysisList.Add("=========================================");
            for (int ii = 0; ii < NUMBER_OF_N_GRAMS_SHOWN; ii++)
            {
                analysisList.Add(writtenUniGramSet.ItemList[ii].AsString());
            }
            analysisList.Add("=========================================");
            analysisList.Add("Spoken 1-grams: ");
            analysisList.Add("=========================================");
            for (int ii = 0; ii < NUMBER_OF_N_GRAMS_SHOWN; ii++)
            {
                analysisList.Add(spokenUniGramSet.ItemList[ii].AsString());
            }



            Dictionary writtenBiGramDictionary = writtenDataSet.Dictionary;
            writtenBiGramSet.ItemList = writtenBiGramDictionary.generateBigramsList(writtenDataSet);
      //      writtenBiGramSet.SortOnFrequency();

            analysisList.Add("=========================================");
            analysisList.Add("Written 2-grams: ");
            analysisList.Add("=========================================");
            for (int ii = 0; ii < NUMBER_OF_N_GRAMS_SHOWN; ii++)
            {
                analysisList.Add(writtenBiGramSet.ItemList[ii].AsString());
            }



            // Add code here for generating and sorting the spoken bigram set.
            // Before sorting, run through the list and remove rare bigrams (speeds up
            // the sorting - we are only interested in the most frequent bigrams anyway;
            // see also the assignment text.



            Dictionary spokenBiGramDictionary = spokenDataSet.Dictionary;
            spokenBiGramSet.ItemList = spokenBiGramDictionary.generateBigramsList(spokenDataSet);
           // spokenBiGramSet.SortOnFrequency();
            

            analysisList.Add("=========================================");
            analysisList.Add("Spoken 2-grams: ");
            analysisList.Add("=========================================");
            for (int ii = 0; ii < NUMBER_OF_N_GRAMS_SHOWN; ii++)
            {
                analysisList.Add(spokenBiGramSet.ItemList[ii].AsString());
            }


            // Step (3) 
            //     Find the 300 most common trigrams (after generating the trigram set.
            //     using the NGramSet class (where you have to write code for appending
            //     n-grams, making sure to keep them sorted in alphabetical order based
            //     on the full token string (see the NGramSet class)

            // Add code here for generating and sorting the written trigrams set.
            // Before sorting, run through the list and remove rare trigrams (speeds up
            // the sorting - we are only interested in the most frequent trigram anyway;
            // see also the assignment text.




            Dictionary writtenTriGramDictionary = writtenDataSet.Dictionary;
            writtenTriGramSet.ItemList = writtenTriGramDictionary.generateTrigramsList(writtenDataSet);
       //     writtenTriGramSet.SortOnFrequency();

            analysisList.Add("=========================================");
            analysisList.Add("Written 3-grams: ");
            analysisList.Add("=========================================");
            for (int ii = 0; ii < NUMBER_OF_N_GRAMS_SHOWN; ii++)
            {
                analysisList.Add(writtenTriGramSet.ItemList[ii].AsString());
            }


            // Add code here for generating and sorting the spoken trigram set.
            // Before sorting, run through the list and remove rare trigrams (speeds up
            // the sorting - we are only interested in the most frequent trigrams anyway;
            // see also the assignment text.


            Dictionary spokenTriGramDictionary = spokenDataSet.Dictionary;
            spokenTriGramSet.ItemList = spokenTriGramDictionary.generateTrigramsList(spokenDataSet);
          //  spokenTriGramSet.SortOnFrequency();

            analysisList.Add("=========================================");
            analysisList.Add("Spoken 3-grams: ");
            analysisList.Add("=========================================");
            for (int ii = 0; ii < NUMBER_OF_N_GRAMS_SHOWN; ii++)
            {
                analysisList.Add(spokenTriGramSet.ItemList[ii].AsString());
            }


            // Then store information about the number of tokens in each set, as well as the number of shared tokens:
            analysisList.Add("=========================================");
            analysisList.Add("No. of distinct unigrams in written set: " + distinctWrittenWords.ToString());
            analysisList.Add("No. of distinct unigrams in spoken set: " + distinctSpokenWords.ToString());
            analysisList.Add("=========================================");

            //    analysisList.Add("Shared:      " ... Add code here ...)
            analysisList.Add("No. of Shared Tokens: " + sharedTokens.ItemList.Count.ToString());
            // Then store information about the 50 tokens with the highest r-values:
            analysisList.Add("=========================================");
            analysisList.Add("Small-r tokens: ");
            analysisList.Add("=========================================");
            for (int i = 0; i < 49; i++)
            {
                analysisList.Add("r = " + sharedTokens.ItemList[i].Ratio + "  | " + sharedTokens.ItemList[i].Token.ToString());
            }
            // Add code here

            // Then store information about the 50 tokens with the lowest r-values:
            analysisList.Add("=========================================");
            analysisList.Add("High-r tokens: ");
            analysisList.Add("=========================================");
            // Add code here
            for (int i = 1; i < 50; i++)
            {
                analysisList.Add("r = " + sharedTokens.ItemList[sharedTokens.ItemList.Count - i].Ratio + "  | "+ sharedTokens.ItemList[sharedTokens.ItemList.Count-i].Token.ToString());
            }

            // =================================================================
            // (5) Write a thread-safe method here for
            // display the analysis in the analysisTextBox
            // see also ThreadSafeToggleMenuItemEnabled(), to see how it's done. 
            // Hint: The ThreadSafeMethod (that uses "Invoke..." can itself
            // call a standard (non-thread safe) method, in case one needs to
            // carry out more operations than just a single assignment...)
            // See also Appendix A.4 in the compendium.
            // ==================================================================



            ThreadSafeShowAnalysis();

            // =============================
            // Don't change below this line:
            // =============================
            ThreadSafeToggleMenuItemEnabled(saveAnalysisToolStripMenuItem, true);
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            processButton.Enabled = false;
            processingThread = new Thread(new ThreadStart(() => ProcessingLoop()));
            processingThread.Start();
        }

        // Here, the results shown in the analysisTextBox are shown. One can also
        // (equivalently) just save the contents of the analysisList (which is indeed
        // what is shown in the textBox...)
        private void saveAnalysisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = TEXT_FILTER;
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter dataWriter = new StreamWriter(saveFileDialog.FileName))
                    {
                        for (int ii = 0; ii < analysisList.Count(); ii++)
                        {
                            dataWriter.WriteLine(analysisList[ii]);
                        }
                        dataWriter.Close();
                    }
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
