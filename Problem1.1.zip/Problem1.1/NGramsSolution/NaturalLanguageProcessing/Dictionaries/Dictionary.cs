﻿using NaturalLanguageProcessing.NGrams;
using NaturalLanguageProcessing.TextData;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.InteropServices;

namespace NaturalLanguageProcessing.Dictionaries
{
    public class Dictionary
    {
        private List<DictionaryItem> itemList;
       
        public Dictionary()
        {
            itemList = new List<DictionaryItem>();
        }

        // Method 1: Make a list of all tokens (i.e. a list of strings) in all sentences,
        // then sort the list. Next, build the list of dictionary items, counting the
        // number of instances in the process.
        //
        // Method 2: Here, you will need a DictionaryItemComparer that compares (in alphabetical order)
        // the tokens of two DictionaryItems. You will use the dictionary item comparer to carry out
        // a binary search, to find the index (in the growing dictionary) of the item
        // corresponding to the token under consideration. If that index is negative,
        // the token is not yet represented in the dictionary: If so, insert it AT THE
        // RIGHT point in the dictionary (to maintain the sort order). Try to figure it
        // out, otherwise ask the examiner or the assistant.
        // If instead the index is non-negative, then increment the count of the item.
        //
        // The running time of the two methods is roughly the same: On a reasonably
        // fast computer, it takes around one minute (in debug mode, much faster in
        // release mode) for a data set of the size considered here.
        public void Build(TextDataSet dataSet)
        {
            DictionaryItemComparer dComp = new DictionaryItemComparer();

            List<string> unSortedList = new List<string>();
            foreach (Sentence sentence in dataSet.SentenceList)
            {
                foreach (string token in sentence.TokenList)
                {
                    unSortedList.Add(token);
                }
            }
            for (int i = 0;i < unSortedList.Count; i++)
            {
                DictionaryItem dictItem = new DictionaryItem(unSortedList[i]);
                int wordIndex = itemList.BinarySearch(dictItem, dComp);
                if (wordIndex < 0)
                {
                    itemList.Insert(~wordIndex,dictItem);
                    dictItem.Count = 1;
                }
                else {
                    itemList[wordIndex].Count++;
                }
            }


            
            itemList.Sort(dComp);
        }


        public List<NGrams.NGram> get300MostCommon()
        {
            List<DictionaryItem> mostCommonList = new List<DictionaryItem>();
            DictionaryItem highest = new DictionaryItem(itemList[0].Token);
            highest.Count = itemList[0].Count;
            //to fill up the list of 300 most occuring words, 
            //search the dataset and find the highest count not in the list already.
            for (int i = 0; i < 299; i++)
            {
                highest.Count = itemList[0].Count;
                foreach (DictionaryItem dItem in itemList)
                {
                    if (dItem.Count >= highest.Count && !mostCommonList.Contains(dItem))
                    {
                        highest = dItem;

                    }
                    else { continue; }
                }
                mostCommonList.Add(highest);
            }

            List<NGrams.NGram> NgramList = new List<NGrams.NGram>();

            for (int i = 0; i < 299; i++)
            {
                List<string> tokenlist = new List<string>();

                tokenlist.Add(mostCommonList[i].Token);
                NgramList.Add(new NGrams.NGram(tokenlist));
                NgramList[i].NumberOfInstances =mostCommonList[i].Count;
            }
            return NgramList;

        }


    public List<NGrams.NGram> get300MostFrequent()
        {
            trimDictionary(3);
            List<DictionaryItem> returnList = new List<DictionaryItem>();
            int LowestCount = 0;
            int HighestCount = 0;

            foreach (DictionaryItem token in itemList)
            {
                int placement = AddToList(token.Count, returnList, LowestCount, HighestCount);
                //set thing for if over 300 items
                if (placement != -1)
                {
                    returnList.Insert(placement, token);
                    if (placement == 0)
                    {
                        HighestCount = token.Count;
                    }
                }
                else if (placement == -1 && returnList.Count < 300)
                {
                    returnList.Add(token);
                    LowestCount = token.Count;
                }
            }

            List<NGrams.NGram> NgramList = new List<NGrams.NGram>();

            for (int i = 0; i < 300; i++)
            {
                List<string> tokenlist = new List<string>();
                tokenlist.Add(returnList[i].Token);
                NgramList.Add(new NGrams.NGram(tokenlist));
                NgramList[i].NumberOfInstances = returnList[i].Count;
            }

            return NgramList;

        }


        public List<NGrams.NGram> generateBigramsList(TextDataSet dataSet)
        {
            Dictionary outputDictionary = new Dictionary();
            List<string> bigramList = new List<string>();

            //dataSet.SentenceList
            foreach (Sentence sentence in dataSet.SentenceList)
            {
                for (int i = 0; i < sentence.TokenList.Count - 1; i++)
                {
                    bigramList.Add(sentence.TokenList[i] + " " + sentence.TokenList[i + 1]);
                }
            }

            for (int i = 0; i < bigramList.Count; i++)
            {
                DictionaryItem dictItem = new DictionaryItem(bigramList[i]);
                int wordIndex = outputDictionary.ItemList.BinarySearch(dictItem, new DictionaryItemComparer());
                if (wordIndex < 0)
                {
                    outputDictionary.ItemList.Insert(~wordIndex, dictItem);
                    dictItem.Count = 1;  
                }
                else
                {
                    outputDictionary.ItemList[wordIndex].Count++;
                }
            }
            outputDictionary.ItemList.Sort((x, y) => x.Count.CompareTo(y.Count));

            List<NGrams.NGram> NgramList = new List<NGrams.NGram>();

            for (int i = 1; i < 301; i++)
            {
                string[] split = outputDictionary.itemList[outputDictionary.itemList.Count - i].Token.Split(' ');
                List<string> tokenlist = new List<string>();
                for (int j = 0; j < 2; j++)
                {
                    tokenlist.Add(split[j]);

                }
                NgramList.Add(new NGrams.NGram(tokenlist));
                NgramList[i - 1].NumberOfInstances = outputDictionary.ItemList[outputDictionary.itemList.Count - i].Count;
            }
            return NgramList;
        }

        public List<NGrams.NGram> generateTrigramsList(TextDataSet dataSet)
        {
            Dictionary outputDictionary = new Dictionary();
            List<string> trigramList = new List<string>();

            //dataSet.SentenceList
            foreach (Sentence sentence in dataSet.SentenceList)
            {
                for (int i = 0; i < sentence.TokenList.Count - 2; i++)
                {
                    trigramList.Add(sentence.TokenList[i] + " " + sentence.TokenList[i + 1] +
                        " " + sentence.TokenList[i + 2]);
                }
            }

            for (int i = 0; i < trigramList.Count; i++)
            {
                DictionaryItem dictItem = new DictionaryItem(trigramList[i]);
                int wordIndex = outputDictionary.ItemList.BinarySearch(dictItem, new DictionaryItemComparer());
                if (wordIndex < 0)
                {
                    outputDictionary.ItemList.Insert(~wordIndex, dictItem);
                    dictItem.Count = 1;
                }
                else
                {
                    outputDictionary.ItemList[wordIndex].Count++;
                }
            }
            outputDictionary.ItemList.Sort((x, y) => x.Count.CompareTo(y.Count));
   
            List<NGrams.NGram> NgramList = new List<NGrams.NGram>();

            for (int i = 1; i < 301; i++)
            {
                string[] split = outputDictionary.itemList[outputDictionary.itemList.Count - i].Token.Split(' ');
                List<string> tokenlist = new List<string>();
                for (int j = 0; j < 3; j++)
                {
                    tokenlist.Add(split[j]);

                }
                NgramList.Add(new NGrams.NGram(tokenlist));
                NgramList[i - 1].NumberOfInstances = outputDictionary.ItemList[outputDictionary.itemList.Count - i].Count;
            }
            return NgramList;
        }


        //Sort dictionary with quicksort
        public void SortDictionary(int leftIndex, int rightIndex)
        {
            var i = leftIndex;
            var j = rightIndex;
            DictionaryItem pivot = itemList[leftIndex];
            while (i <= j)
            {
                while (itemList[i].Count < pivot.Count)
                {
                    i++;
                }

                while (itemList[j].Count > pivot.Count)
                {
                    j--;
                }
                if (i <= j)
                {
                    DictionaryItem temp = itemList[i];
                    itemList[i] = itemList[j];
                    itemList[j] = temp;
                    i++;
                    j--;
                }
            }

            if (leftIndex < j)
                SortDictionary(leftIndex, j);
            if (i < rightIndex)
                SortDictionary(i, rightIndex);
        }



      
        public int iterativeBinarySearch(DictionaryItem word)
        {
            DictionaryItemComparer dic = new DictionaryItemComparer(); //hehe
            int start = 0;
            int end = itemList.Count-1;
           
            int idx = (start + end) / 2;

            if (dic.Compare(itemList[0],word) == 0)
            {
                return 0;
            }

            while (start != end)
            {

                idx = (start + end) / 2;
                //wordToken = itemList[idx].Token;
                //relPosition = string.Compare(word,wordToken);

                if (itemList[idx] == word)
                {
                    return idx;
                }
                else if (dic.Compare(itemList[idx],word) < 0)
                {
                    start = idx + 1;
                }
                else
                {
                    end = idx - 1;
                }
            }
            return -1;
        }


        private int AddToList(int tokenCount, List<DictionaryItem> list, int lowest, int highest)
        {
            if (tokenCount > highest)
            {
                return 0;
            }
            if (tokenCount < lowest)
            {
                return -1;
            }

            for (int i = list.Count - 1; i >= 0; i--)
            {
                if (tokenCount < list[i].Count)
                {
                    return i + 1;
                }
            }

            return -1;
        }

 

        public void quickSort(int leftIndex, int rightIndex)
        {
            var i = leftIndex;
            var j = rightIndex;
            DictionaryItem pivot = itemList[leftIndex];
            while (i <= j)
            {
                //while (itemList[i].Token < itemList[j].Token)
                while (itemList[i].Ratio < itemList[j].Ratio)
                {
                    i++;
                }

                //while (itemList[j].Count > pivot.Count)
                while (itemList[j].Ratio > pivot.Ratio)
                {
                    j--;
                }
                if (i <= j)
                {
                    DictionaryItem temp = itemList[i];
                    itemList[i] = itemList[j];
                    itemList[j] = temp;
                    i++;
                    j--;
                }
            }

            if (leftIndex < j)
                quickSort(leftIndex, j);
            if (i < rightIndex)
                quickSort(i, rightIndex);
        }




        public List<DictionaryItem> get50LowRatioTokens()
        {

            List<DictionaryItem> lowRatioList = new List<DictionaryItem>();
            DictionaryItem lowest = new DictionaryItem(itemList[0].Token);
            lowest.Ratio = itemList[0].Ratio;
            for (int i = 0; i < 49; i++)
            {
                lowest.Ratio = itemList[0].Ratio;
                foreach (DictionaryItem dItem in itemList)
                {
                    if (dItem.Ratio > lowest.Ratio && lowRatioList.Contains(dItem) == false)
                    {
                        lowest = dItem;
                    }else { continue; } 

                }
                lowRatioList.Add(lowest);
            }
            return lowRatioList;
        }

        public List<DictionaryItem> get50HighRatioTokens()
        {

            List<DictionaryItem> highRatioList = new List<DictionaryItem>();
            DictionaryItem highest = new DictionaryItem(itemList[0].Token);
            highest.Ratio = itemList[0].Ratio;
            for (int i = 0; i < 49; i++)
            {
                highest.Ratio = itemList[0].Ratio;
                foreach (DictionaryItem dItem in itemList)
                {
                    if (dItem.Ratio > highest.Ratio && highRatioList.Contains(dItem) == false)
                    {
                        highest = dItem;
                    }
                    else {continue;}
                }
                highRatioList.Add(highest);
            }
            return highRatioList;
        }

       

        public void trimDictionary(int lowerLimit)
        {
            int i = 0;
            while (i < itemList.Count)
            {
                if (itemList[i].Count < lowerLimit)
                {
                    itemList.RemoveAt(i);
                }
                else
                {
                    i++;
                }
            }
        }
        public List<DictionaryItem> ItemList
        {
            get { return itemList; }
            set { itemList = value; }
        }
    }
}
