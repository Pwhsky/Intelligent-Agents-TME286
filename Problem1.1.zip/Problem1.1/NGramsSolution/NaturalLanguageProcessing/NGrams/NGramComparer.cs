﻿using System.Collections.Generic;

namespace NaturalLanguageProcessing.NGrams
{
    public class NGramComparer : IComparer<NGram>
    {
        public int Compare(NGram item1, NGram item2)
        {
            return item1.TokenString.CompareTo(item2.TokenString);
        }
    }
}
