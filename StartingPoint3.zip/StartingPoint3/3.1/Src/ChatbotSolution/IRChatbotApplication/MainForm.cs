﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using ChatbotLibrary;

namespace IRChatbotApplication
{
    public partial class MainForm : Form
    {
        private DialogueCorpus corpus = null; // The dialogue corpus, consisting of sentence pairs.
        private Chatbot chatbot;
        private List<string> dialogueLinesList;
        private List<string> conversationData; //conversation identifiers
        private List<string> lineIdList;


        // Add fields here as needed, e.g. for the raw data.

        public MainForm()
        {
            InitializeComponent();
            if (!DesignMode)
            {
                inputTextBox.InputReceived += new EventHandler<StringEventArgs>(HandleInputReceived);
            }
        }
     
        private void loadRawDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
               
                openFileDialog.Filter = "Text files (*.tsv)|*.tsv";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    StreamReader dataReader = new StreamReader(openFileDialog.FileName);

                    {
                        List<string> tempDataLinesList = new List<string>();
                        List<string> tempLineIdList = new List<string>();
                        while (!dataReader.EndOfStream)
                        {

                            string[] dataLine = dataReader.ReadLine().
                                Replace("\n", "").
                                Split(new char[] { '\t' }, count: 5, StringSplitOptions.RemoveEmptyEntries);

                            dataLine[0] = dataLine[0].Trim(new char[] { '\u0022' });

                            if (dataLine.Length != 5)
                            {
                                continue;
                            }
                            //To do: Find out a way to only add sentence pairs

                            
                            {
                                tempDataLinesList.Add(dataLine[4].ToString()); //4th field contains the dialogue line
                                tempLineIdList.Add(dataLine[0]);
                            }
                          
                        }
                        dialogueLinesList = tempDataLinesList;
                        lineIdList = tempLineIdList;
                        dataReader.Close();
                        
                    }
                }
            }
        }
       
        private void loadConversationDataToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Text files (*.tsv)|*.tsv";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    StreamReader dataReader = new StreamReader(openFileDialog.FileName);

                    {
                        List<string> tempDataLinesList = new List<string>();
                        while (!dataReader.EndOfStream)
                        {

                            string[] dataLine = dataReader.ReadLine().
                                Replace("\n", "").
                                Split(new char[] { '\t' }, count: 4, StringSplitOptions.RemoveEmptyEntries);

                            dataLine[0] = dataLine[0].Trim(new char[] { '\u0022' });

                            if (dataLine.Length != 4)
                            {
                                continue;
                            }
                            //To do: Find out a way to only add sentence pairs


                            {
                                tempDataLinesList.Add(dataLine[3].ToString()); //4th field contains the dialogue line
                            }

                        }
                        conversationData = tempDataLinesList;
                        dataReader.Close();
                        generateDialogueCorpusButton.Enabled = true;
                    }
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //
        // This method you get for free ... :)
        private void generateChatBotButton_Click(object sender, EventArgs e)
        {
            generateChatBotButton.Enabled = false;
            chatbot = new Chatbot();
            chatbot.SetDialogueCorpus(corpus);
            inputTextBox.Enabled = true;
            mainTabControl.SelectedTab = chatTabPage;
        }

        //
        // To do: Write the method below.
        //
        // This method is called whenever the user enters text (= hits return) in
        // the input text box.
        // 
        // The input sentence should be passed to the chatbot, which then generates
        // an output. Both the (user) input and the (chatbot) output should be displayed in the
        // listbox (listbox.Items.Insert(0, ...), so that one can follow the
        // entire dialogue
        // 
        private void HandleInputReceived(object sender, StringEventArgs e)
        {
            string inputSentence = e.Information;

            // Add code here ...
        }

        // To do: Write this method. Hint: Use the StreamWriter class
        // as well as the AsString() method from the DialogueCorpusItem class.
        private void saveDialogueCorpusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // This method should save the dialogue corpus, with one exchange per
            // row, i.e. S_1, tab-character ("\t"), S_2. As mentioned in the assignment
            // you must hand in this file *in addition* to the raw data.
        }

        private void generateDialogueCorpusButton_Click(object sender, EventArgs e)
        {
   

           


            corpus = new DialogueCorpus();
            corpus.Process(dialogueLinesList,conversationData,lineIdList);

            // Add methods (in the DialogueCorpus class) for processing the raw
            // data, e.g. corpus.Process(rawData) ...


            generateChatBotButton.Enabled = true;
            saveDialogueCorpusToolStripMenuItem.Enabled = true;
        }

        
    }
}
