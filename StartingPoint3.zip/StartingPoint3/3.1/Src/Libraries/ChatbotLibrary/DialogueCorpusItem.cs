﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Schema;
using static System.Net.Mime.MediaTypeNames;

namespace ChatbotLibrary
{
    [DataContract]
    public class DialogueCorpusItem
    {
        // This class stores a sentence pair as well as the (normalized) TF-IDF embedding
        // for the query sentence (S_1) (you must compute it first, though; see below).
        //

        private string query; // = S_1 in the assignment (used for computing cosine similarity) (need not be a question, though!)
        private string response; // = S_2 in the assignment
       // private List<double> tfIdfVector; // Must be generated - see below.

        private List<Tuple<int, double>> sparsetfIdfVector; //Contains information about index location in vocabulary to save memory


        // You can add fields here, if you also wish to store the tokenized version of
        // each sentence, or (better) the indices of the words (tokens) from the vocabulary



        // This method returns the sentence pair in the format required for saving the
        // dialogue corpus to file (as specified in the assignment).
        //
        // NOTE! Very important! The query and response sentences may *not* contain any tab (\t) characters,
        // since that character is used for separating the two sentences in the AsString() method.
        public string AsString()
        {
            string itemAsString = query + " \t " + response;
            return itemAsString;
        }

        public DialogueCorpusItem(string query, string response)
        {
            this.query = query;
            this.response = response;
            List<Tuple<int,double>> sparsetfIdfVector = new List<Tuple<int, double>>();
        }

        public void ComputeTFIDFVector(Vocabulary dictionary)
        {

            List<string> queryTokens = TokenizeQuery(query);
            
            List<Tuple<int,double>> tempTuple = new List<Tuple<int,double>>();
            //Initialize an empty vector of vocabulary length

            //List<Tuple<int, double>> sparseIdfVector = new List<Tuple<int, double>>() ;

            //Build the vector:
            
            foreach (string token in queryTokens)
            {
                if (string.IsNullOrEmpty(token) == true) { continue; }
                WordData termToSearch = new WordData();
                termToSearch.Word = token;
                int tokenIndexInVocabulary = dictionary.WordDataList.BinarySearch(termToSearch, new WordDataComparer());
                if (tokenIndexInVocabulary < 0) { continue; }

                double termFrequency = queryTokens.Count(s => s == token);

                Tuple<int,double> tupleToAdd = new Tuple<int, double>
                    (tokenIndexInVocabulary, (dictionary.WordDataList[tokenIndexInVocabulary].IDF )* termFrequency);

                tempTuple.Add(tupleToAdd);
            }
            // Write this method
            // It should generate the (note!) normalized (to unit length)
            // TF-IDF vector for the query sentence (S_1) 

            sparsetfIdfVector = normalizeTuple(tempTuple);
        }
      

        public List<Tuple<int,double>> sparseTFIDFVector
        {
            get { return sparsetfIdfVector; }
            set { sparsetfIdfVector = value; }
        }

        public  List<Tuple<int, double>> normalizeTuple(List<Tuple<int, double>> inputTuple)
        {
            List<Tuple<int, double>> outputTuple = new List<Tuple<int, double>>();
            double norm = 0;

            foreach (var entry in inputTuple)
            {
                norm += entry.Item2 * entry.Item2;

            }

            norm = Math.Sqrt(norm);
            for (int i = 0; i < inputTuple.Count; i++)
            {
                Tuple<int, double> tupleToAdd = new Tuple<int, double>
                    (inputTuple[i].Item1, inputTuple[i].Item2 / norm);

                    outputTuple.Add(tupleToAdd);
            }

                return outputTuple;
        }

        [DataMember]
        public string Query
        {
            get { return query; }
            set { query = value; }
        }

        [DataMember]
        public string Response
        {
            get { return response; }
            set { response = value; }
        }
        public List<string> TokenizeQuery(string queryLine)
        {

            queryLine = queryLine.ToLower();
            queryLine = queryLine.Replace("\n", "").Replace("\t", "").Replace("\u0085", "");
            queryLine = Regex.Replace(queryLine, @"[^\w\s'-]", "");

            queryLine = new string((from c in queryLine
                                       where char.IsWhiteSpace(c) || char.IsLetterOrDigit(c) select c).ToArray());

            List<string> tempList = queryLine.Split(' ').ToList();

            for (int i = 0; i < tempList.Count; i++)
            {
                if (string.IsNullOrWhiteSpace(tempList[i])) { tempList.RemoveAt(i); }
            }

            return tempList;

        }
    }
}
