﻿using ChatbotLibrary;
using System.Collections.Generic;

namespace NaturalLanguageProcessing.Dictionaries
{
    public class WordDataComparer : IComparer<WordData>
    {
        public int Compare(WordData item1, WordData item2)
        {
            return item1.Word.CompareTo(item2.Word);
        }
    }
}

