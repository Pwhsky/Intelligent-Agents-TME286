﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace ChatbotLibrary
{
    public class Chatbot
    {
        protected const int DEFAULT_NUMBER_OF_MATCHES = 5;

        protected DialogueCorpus dialogueCorpus;
        protected Random randomNumberGenerator;
        protected int numberOfMatches = DEFAULT_NUMBER_OF_MATCHES;

        public virtual void Initialize()
        {
            randomNumberGenerator = new Random();
        }

        public void SetDialogueCorpus(DialogueCorpus dialogueCorpus)
        {
            this.dialogueCorpus = dialogueCorpus;
        }

        //
        // ToDo: Write the method below
        //
        // Given an input sentence, the method should 
        // compute the cosine similarity between the normalized
        // TF-IDF vector of the test sentence and the normalized
        // TF-IDF vectors of every sentence S_1 (i.e. the Query sentence
        // in each DialogueCorpusItem). The results should then be
        // sorted (you may add a class for this, perhaps with two fields,
        // one field for the index of the sentence pair (in the dialogue corpus), and
        // one field for the cosine similarity. Finally, a sentence pair should
        // be selected (as described below) and the corresponding Response should be returned.
        //
        // Then 
        // (i) sort the results in falling order of cosine similarity,
        // (ii) pick a random sentence pair (index) from among the top five (numberOfMatches, see above).
        // (iii) return sentence S_2 (Response) from the selected pair (DialogueCorpusItem).
        //
        //
        public virtual string GenerateResponse(string inputSentence)
        {
            int vocabularyLength = dialogueCorpus.Vocabulary.WordDataList.Count;
  

            List<string> inputSentenceTokens = TokenizeInput(inputSentence);
            List<Tuple<int,double>> sparseTfidfTuple = ComputeTFIDFVector(dialogueCorpus.Vocabulary, inputSentenceTokens);
            List<Tuple<double, string>> outputTuple = new List<Tuple<double, string>>();


            double inputSentenceNorm = computeNorm(sparseTfidfTuple);
            double comparisonSentenceNorm;
            double cosineSimilarity;
            double hadamardProduct;
            //No2w compare the nonSparseTFIDF with the sentence TFIDF's
            for (int i = 1; i < dialogueCorpus.ItemList.Count; i++)
            {
                
                comparisonSentenceNorm = computeNorm(dialogueCorpus.ItemList[i].sparseTFIDFVector);
                hadamardProduct       = HadamardProduct(sparseTfidfTuple, dialogueCorpus.ItemList[i].sparseTFIDFVector);
                

                double normProduct     = comparisonSentenceNorm * inputSentenceNorm;
                cosineSimilarity       = hadamardProduct/normProduct ;
                outputTuple.Add(Tuple.Create(cosineSimilarity, dialogueCorpus.ItemList[i].Response));
            }
            
            
            outputTuple.Sort((x, y) => {
                int compare = y.Item2.CompareTo(x.Item2);
                return compare == 0 ? y.Item1.CompareTo(x.Item1) : compare;
            });

            Random rnd = new Random();
            int randN = rnd.Next(0, DEFAULT_NUMBER_OF_MATCHES-1);


            return (outputTuple[randN].Item2).ToString();
        }


        public List<string> TokenizeInput(string inputLine)
        {

            inputLine = inputLine.ToLower();
            inputLine = inputLine.Replace("\u0085", "").Replace("\t", "");

            inputLine = new string((from c in inputLine
                                    where char.IsWhiteSpace(c) || char.IsLetterOrDigit(c)
                                    select c).ToArray());

            List<string> tempList = inputLine.Split(' ').ToList();

            return tempList;

        }

        public List<Tuple<int,double>> ComputeTFIDFVector(Vocabulary dictionary,List<string> inputSentenceTokens)
        {
            List<Tuple<int,double>> outputTuple       = new List<Tuple<int, double>>();
            List<Tuple<int,double>> sparsetfIdfVector = new List<Tuple<int, double>>();
        
            //Initialize an empty vector of vocabulary length

            //List<Tuple<int, double>> sparseIdfVector = new List<Tuple<int, double>>() ;

            //Build the vector:
            foreach (string token in inputSentenceTokens)
            {
                if (string.IsNullOrEmpty(token) == true) { continue; }

                WordData termToSearch = new WordData();
                termToSearch.Word = token;
                int tokenIndexInVocabulary = dictionary.WordDataList.BinarySearch(termToSearch, new WordDataComparer());
                if (tokenIndexInVocabulary < 0) {continue;}
                double termFrequency = token.Where(x => inputSentenceTokens.Contains(x.ToString())).Count();
                sparsetfIdfVector.Add(Tuple.Create(tokenIndexInVocabulary, dictionary.WordDataList[tokenIndexInVocabulary].IDF * termFrequency));
             
            }

            //Normalize the vector:
            double norm = 0;
            foreach (var entry in sparsetfIdfVector)
            {
                norm += entry.Item2 * entry.Item2;
            }
            norm = Math.Sqrt(norm);

            for (int i = 0; i < sparsetfIdfVector.Count; i++)
            {
                outputTuple.Add(Tuple.Create
                    (sparsetfIdfVector[i].Item1, sparsetfIdfVector[i].Item2 / norm));

            }

            return outputTuple;

        }

        private double computeNorm(List<Tuple<int, double>> sparseTfidfTuple)
        {
            double norm = 0;
                foreach (var entry in sparseTfidfTuple)
            {
                norm += entry.Item2 * entry.Item2;
            }
            norm = Math.Sqrt(norm);

            return norm;
        }
        private double HadamardProduct(List<Tuple<int, double>> tuple1, List<Tuple<int, double>> tuple2)
        {
            double productSum = 0;
            
            for (int i = 0; i < tuple1.Count; i++)
            {
                if (tuple1[i].Item1 == tuple2[i].Item1) { 
                productSum += tuple1[i].Item2 * tuple2[i].Item2;
                }
                else { continue; }
            }
            return productSum;
        }


    }
}
